# mypackage
this  was my first package

# how to install